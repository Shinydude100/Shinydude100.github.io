param(
  [string]$LogDirectory = "$PSScriptRoot\Logs"
)

# 1. Create Logs directory and initiate Global Transcript Logging
if (-not (Test-Path $LogDirectory)) { 
    New-Item -Path $LogDirectory -ItemType Directory | Out-Null 
}
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $LogDirectory "Maintenance_$timestamp.log"

Start-Transcript -Path $LogFile -Append | Out-Null

function Run-Stage {
  param(
    [int]   $Number,
    [int]   $Total,
    [string]$Label,
    [scriptblock]$Action
  )

  $pct = [math]::Floor((($Number-1)/$Total)*100)
  Write-Progress -Activity "System Rescue & Maintenance" `
                 -Status "Stage ${Number} of ${Total}: ${Label}" `
                 -PercentComplete $pct

  Write-Output "`n========================================"
  Write-Output "STAGE ${Number}: $Label"
  Write-Output "========================================"
  
  & $Action

  if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne $null) {
      Write-Warning "Stage $Number finished with exit code $LASTEXITCODE."
  }

  $pct = [math]::Floor(($Number/$Total)*100)
  Write-Progress -Activity "System Rescue & Maintenance" `
                 -Status "Stage ${Number} of ${Total}: ${Label} (Done)" `
                 -PercentComplete $pct
}

$totalStages = 6

# Stage 1: Pinpoint Crash Causes
Run-Stage -Number 1 -Total $totalStages -Label "Extracting BSOD Crash Logs" -Action {
  Write-Output "Scanning Event Viewer for recent system crashes..."
  # Look specifically for the 'BugCheck' provider to eliminate false positives
  $crashes = Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='BugCheck'; Id=1001} -MaxEvents 5 -ErrorAction SilentlyContinue
  
  if ($crashes) {
      Write-Output "CRITICAL: Recent System Crashes Found. Review the details below."
      foreach ($crash in $crashes) {
          Write-Output "`nTime: $($crash.TimeCreated)"
          Write-Output "Details: $($crash.Message)"
          Write-Output "----------------------------------------"
      }
  } else {
      Write-Output "No recent BugCheck (BSOD) events found. System appears stable at the OS level."
  }
}

# Stage 2: DISM Repair
Run-Stage -Number 2 -Total $totalStages -Label "Repairing Windows OS image" -Action {
  DISM /Online /Cleanup-Image /RestoreHealth
}

# Stage 3: System File Checker
Run-Stage -Number 3 -Total $totalStages -Label "Scanning and repairing system files" -Action {
  sfc /scannow
}

# Stage 4: Disk Check (Live Scan)
Run-Stage -Number 4 -Total $totalStages -Label "Checking NTFS file system for corruption" -Action {
  chkdsk C: /scan
}

# Stage 5: Memory & Paging File Fixes
Run-Stage -Number 5 -Total $totalStages -Label "Applying Nonpaged Area Fixes" -Action {
  Write-Output "Enabling 'Clear Page File at Shutdown' to purge corrupted memory caches..."
  try {
      Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name "ClearPageFileAtShutdown" -Value 1 -ErrorAction Stop
      Write-Output "Registry updated successfully. Page file will be cleared on next reboot."
  } catch {
      Write-Warning "Failed to update registry for Page File clearing. Ensure script is running as Administrator."
  }
}

# Stage 6: Minidump Extraction for WinDbg Analysis
Run-Stage -Number 6 -Total $totalStages -Label "Extracting Minidump (.dmp) Files" -Action {
  $MinidumpDir = "C:\Windows\Minidump"
  $DumpDestination = Join-Path $LogDirectory "Minidumps_$timestamp"

  if (Test-Path $MinidumpDir) {
      # Grab all .dmp files
      $dmpFiles = Get-ChildItem -Path $MinidumpDir -Filter "*.dmp" -ErrorAction SilentlyContinue
      
      if ($dmpFiles.Count -gt 0) {
          Write-Output "Found $($dmpFiles.Count) minidump file(s). Securing copies for WinDbg..."
          New-Item -Path $DumpDestination -ItemType Directory -Force | Out-Null
          
          foreach ($file in $dmpFiles) {
              Copy-Item -Path $file.FullName -Destination $DumpDestination -Force -ErrorAction Continue
              Write-Output " -> Copied: $($file.Name)"
          }
          Write-Output "`nMinidumps successfully secured in: $DumpDestination"
      } else {
          Write-Output "No raw .dmp files found in $MinidumpDir."
      }
  } else {
      Write-Output "Minidump directory not found. The system may not have crashed recently, or dump creation is disabled."
  }

  Write-Output "`nPreparing Windows Memory Diagnostic Tool..."
  Write-Output "To rule out failing RAM, a physical memory test is highly recommended."
  Start-Process -FilePath "mdsched.exe"
}

# Finish
Write-Progress -Activity "System Rescue & Maintenance" -Completed
Write-Host "`nRescue operations complete! Please review the transcript log in your Logs folder." -ForegroundColor Green
Write-Host "A memory diagnostic prompt should be open. It is highly recommended to restart and test your RAM." -ForegroundColor Yellow

Stop-Transcript | Out-Null
Read-Host "Press Enter to exit"