param(
  [string]$LogFile
)

function Run-Stage {
  param(
    [int]   $Number,
    [int]   $Total,
    [string]$Label,
    [scriptblock]$Action
  )

  # MODIFIED: Calculation is now done *before* the Write-Progress command.
  $pct = [math]::Floor((($Number-1)/$Total)*100)
  Write-Progress -Activity "System Maintenance" `
                 -Status "Stage ${Number} of ${Total}: ${Label}" `
                 -PercentComplete $pct

  # Run the action, logging output
  & $Action

  # MODIFIED: Calculation is now done *before* the Write-Progress command.
  $pct = [math]::Floor(($Number/$Total)*100)
  Write-Progress -Activity "System Maintenance" `
                 -Status "Stage ${Number} of ${Total}: ${Label} (Done)" `
                 -PercentComplete $pct
}

$totalStages = 3

# Stage 1: System File Checker
Run-Stage -Number 1 -Total $totalStages -Label "Scanning system files" -Action {
  sfc /scannow >> $LogFile 2>&1
}

# Stage 2: Disk Check
Run-Stage -Number 2 -Total $totalStages -Label "Checking disk for errors" -Action {
  "Y" | chkdsk C: /f /r >> $LogFile 2>&1
}

# Stage 3: DISM Repair
Run-Stage -Number 3 -Total $totalStages -Label "Repairing Windows image" -Action {
  DISM /Online /Cleanup-Image /RestoreHealth >> $LogFile 2>&1
}

# Finish
Write-Progress -Activity "System Maintenance" -Completed
Write-Host "`nMaintenance complete!" -ForegroundColor Green

# Pause so window doesn’t auto-close
Read-Host "Press Enter to exit"