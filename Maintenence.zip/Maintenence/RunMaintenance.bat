@echo off
TITLE System Rescue Launcher

:: 1. Check for Administrator Privileges
net session >nul 2>&1
if errorlevel 1 (
    echo =====================================================
    echo  CRITICAL: Administrator Privileges Required
    echo =====================================================
    echo This system rescue utility must modify registry keys
    echo and execute deep system scans.
    echo.
    echo Please close this window, right-click the file, 
    echo and select "Run as Administrator".
    echo.
    pause
    exit /b
)

:: 2. Launch the System Rescue PowerShell Script
echo Launching System Rescue Utility...
echo.
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0MaintenanceUtility.ps1"

:: 3. Exit (PowerShell handles the final pause and instructions)
exit /b